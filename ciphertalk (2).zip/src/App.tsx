import React, { useState, useEffect, useRef, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageSquare, 
  UserPlus,
  LogOut, 
  Send, 
  User, 
  Plus, 
  AlertCircle, 
  Check, 
  Loader2, 
  Wifi, 
  WifiOff, 
  ArrowLeft,
  Users,
  Search,
  MessageCircle,
  Clock,
  Palette,
  Sparkles,
  Settings,
  X,
  Edit2,
  Lock,
  MessageSquarePlus,
  Compass,
  Monitor,
  CheckCircle2,
  CornerDownRight,
  Trash2,
  Paperclip,
  Image as ImageIcon,
  Video as VideoIcon,
  Music as MusicIcon
} from 'lucide-react';

// --- Types & Interfaces ---

interface UserPayload {
  id: string;
  username: string;
  displayName: string;
  createdAt: number;
  statusText?: string;
  avatarGradient?: string;
  customTheme?: string;
}

interface Friend {
  id: string;
  username: string;
  displayName: string;
  isOnline: boolean;
  statusText?: string;
  avatarGradient?: string;
}

interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  text: string;
  timestamp: number;
  mediaType?: 'image' | 'video' | 'audio';
  mediaUrl?: string;
}

// --- Preset Theme Definitions ---

interface ThemePreset {
  id: string;
  name: string;
  description: string;
  bgClass: string;
  panelClass: string;
  borderClass: string;
  headerClass: string;
  textPrimaryClass: string;
  textSecondaryClass: string;
  accentClass: string;
  glassMorphism: boolean;
}

const THEME_PRESETS: { [key: string]: ThemePreset } = {
  liquid_glass: {
    id: 'liquid_glass',
    name: 'macOS Tahoe (Liquid Glass)',
    description: 'Smooth translucent frosted panes and active colorful background fluid gradients',
    bgClass: 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-indigo-950 to-black',
    panelClass: 'bg-white/10 dark:bg-slate-900/40 backdrop-blur-2xl border border-white/20 shadow-[0_24px_50px_-15px_rgba(0,0,0,0.6)] rounded-3xl',
    borderClass: 'border-white/15 dark:border-white/10',
    headerClass: 'bg-white/5 backdrop-blur-md border-b border-white/10',
    textPrimaryClass: 'text-white font-sans',
    textSecondaryClass: 'text-indigo-200/70',
    accentClass: 'text-teal-400 bg-teal-400/10 hover:bg-teal-400/20',
    glassMorphism: true
  },
  slate_midnight: {
    id: 'slate_midnight',
    name: 'Sleek Midnight',
    description: 'Minimalistic hyper-focused slate with high visual accuracy and contrast',
    bgClass: 'bg-slate-950',
    panelClass: 'bg-slate-900 border border-slate-800 shadow-2xl rounded-2xl',
    borderClass: 'border-slate-800',
    headerClass: 'bg-slate-900 border-b border-slate-800',
    textPrimaryClass: 'text-slate-100 font-sans',
    textSecondaryClass: 'text-slate-400',
    accentClass: 'text-sky-400 bg-sky-400/10 hover:bg-sky-400/25',
    glassMorphism: false
  },
  cyberpunk: {
    id: 'cyberpunk',
    name: 'Solar Cyberpunk',
    description: 'High contrast tactical dark mode with glowing electronic amber accents',
    bgClass: 'bg-neutral-950',
    panelClass: 'bg-neutral-900 border border-amber-500/20 shadow-[0_4px_30px_-5px_rgba(245,158,11,0.1)] rounded-xl font-mono',
    borderClass: 'border-amber-500/10',
    headerClass: 'bg-neutral-900/90 border-b border-amber-500/20',
    textPrimaryClass: 'text-amber-500 font-mono',
    textSecondaryClass: 'text-amber-500/50',
    accentClass: 'text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30',
    glassMorphism: false
  },
  aurora: {
    id: 'aurora',
    name: 'Aurora Borealis',
    description: 'Earthy boreal aesthetic with shimmering soft emerald & cyan lighting fields',
    bgClass: 'bg-gradient-to-tr from-slate-950 via-teal-950 to-emerald-950',
    panelClass: 'bg-teal-950/40 backdrop-blur-3xl border border-emerald-500/20 shadow-[0_20px_40px_-5px_rgba(16,185,129,0.15)] rounded-2xl',
    borderClass: 'border-emerald-500/15',
    headerClass: 'bg-teal-950/25 backdrop-blur border-b border-emerald-500/20',
    textPrimaryClass: 'text-emerald-100 font-sans',
    textSecondaryClass: 'text-emerald-400/60',
    accentClass: 'text-emerald-400 bg-emerald-400/10 hover:bg-emerald-400/20',
    glassMorphism: true
  }
};

// --- Custom Avatar Preset Gradients ---

const AVATAR_GRADIENTS: { [key: string]: { name: string; classes: string; initialsColor: string } } = {
  liquid_sapphire: {
    name: 'Liquid Sapphire',
    classes: 'bg-gradient-to-tr from-blue-500 via-sky-500 to-indigo-600 shadow-[0_0_15px_rgba(59,130,246,0.5)]',
    initialsColor: 'text-white'
  },
  aurora_emerald: {
    name: 'Aurora Emerald',
    classes: 'bg-gradient-to-tr from-emerald-400 via-teal-500 to-cyan-600 shadow-[0_0_15px_rgba(52,211,153,0.5)]',
    initialsColor: 'text-slate-950 font-bold'
  },
  velvet_rose: {
    name: 'Velvet Rose',
    classes: 'bg-gradient-to-tr from-pink-500 via-rose-500 to-violet-600 shadow-[0_0_15px_rgba(244,63,94,0.5)]',
    initialsColor: 'text-white'
  },
  golden_refraction: {
    name: 'Golden Refraction',
    classes: 'bg-gradient-to-tr from-amber-400 via-orange-500 to-yellow-600 shadow-[0_0_15px_rgba(251,191,36,0.5)]',
    initialsColor: 'text-slate-950 font-bold'
  },
  solstice_violet: {
    name: 'Solstice Violet',
    classes: 'bg-gradient-to-tr from-fuchsia-500 via-purple-600 to-pink-500 shadow-[0_0_15px_rgba(217,70,239,0.5)]',
    initialsColor: 'text-white'
  }
};

// --- Message Bubble Aesthetics ---

const BUBBLE_GRADIENTS: { [key: string]: { name: string; meClasses: string; friendClasses: string } } = {
  tahoe_teal: {
    name: 'Tahoe Ocean (Teal)',
    meClasses: 'bg-gradient-to-tr from-teal-400 via-cyan-500 to-blue-500 text-slate-950 font-medium',
    friendClasses: 'bg-slate-800 text-white'
  },
  glass_white: {
    name: 'Liquid Sheen (Glass)',
    meClasses: 'bg-white/20 hover:bg-white/25 backdrop-blur border border-white/25 text-white',
    friendClasses: 'bg-white/5 backdrop-blur border border-white/10 text-slate-100'
  },
  solstice_sunset: {
    name: 'Solstice Sunset',
    meClasses: 'bg-gradient-to-tr from-rose-500 via-pink-500 to-indigo-600 text-white',
    friendClasses: 'bg-slate-800/80 text-teal-100 border border-teal-500/15'
  },
  industrial_amber: {
    name: 'Cyber Warning (Amber)',
    meClasses: 'bg-amber-400 text-neutral-950 font-bold border border-amber-300 shadow-[0_0_10px_rgba(251,191,36,0.4)]',
    friendClasses: 'bg-neutral-800 text-amber-500 border border-amber-500/20'
  }
};

// --- Avatar Component Helper ---

function UserAvatar({ 
  gradientId, 
  displayName, 
  isOnline, 
  size = 'md' 
}: { 
  gradientId?: string; 
  displayName?: string; 
  isOnline?: boolean; 
  size?: 'sm' | 'md' | 'lg' | 'xl' 
}) {
  const gradient = AVATAR_GRADIENTS[gradientId || 'liquid_sapphire'] || AVATAR_GRADIENTS.liquid_sapphire;
  const initials = (displayName || '?')
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map(w => w[0])
    .join('')
    .toUpperCase();

  const dimensions = {
    sm: 'w-8 h-8 text-[11px] rounded-lg',
    md: 'w-10 h-10 text-[13px] rounded-xl',
    lg: 'w-12 h-12 text-[15px] rounded-2xl',
    xl: 'w-16 h-16 text-[20px] rounded-3xl'
  }[size];

  return (
    <div className={`relative shrink-0 flex items-center justify-center transition-all duration-300 ${dimensions} ${gradient.classes}`}>
      <span className={`font-bold tracking-tight select-none ${gradient.initialsColor}`}>
        {initials || '?'}
      </span>
      {isOnline && (
        <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full ring-2 ring-slate-950 shadow-md animate-pulse" />
      )}
    </div>
  );
}

export default function App() {
  // --- Auth & Identity State ---
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('chat_token'));
  const [currentUser, setCurrentUser] = useState<UserPayload | null>(() => {
    const saved = localStorage.getItem('chat_user');
    return saved ? JSON.parse(saved) : null;
  });

  // --- App Styling States (Saved on Server & LocalStorage) ---
  const [themeId, setThemeId] = useState<string>(() => localStorage.getItem('app_theme') || 'liquid_glass');
  const [avatarGradient, setAvatarGradient] = useState<string>(() => localStorage.getItem('avatar_gradient') || 'liquid_sapphire');
  const [bubbleTheme, setBubbleTheme] = useState<string>(() => localStorage.getItem('bubble_theme') || 'tahoe_teal');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // --- Navigation & Panel states ---
  const [isRegister, setIsRegister] = useState(false);
  const [selectedFriend, setSelectedFriend] = useState<Friend | null>(null);

  // --- Form controllers ---
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [displayNameInput, setDisplayNameInput] = useState('');
  const [statusTextInput, setStatusTextInput] = useState('');
  
  const [friendUsernameInput, setFriendUsernameInput] = useState('');
  const [messageText, setMessageText] = useState('');
  const [friendsFilter, setFriendsFilter] = useState('');

  // --- Live lists ---
  const [friendsList, setFriendsList] = useState<Friend[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);

  // --- Alerts & loading states ---
  const [errorText, setErrorText] = useState<string | null>(null);
  const [successText, setSuccessText] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSseConnected, setIsSseConnected] = useState(false);

  const [selectedFile, setSelectedFile] = useState<{
    name: string;
    type: 'image' | 'video' | 'audio';
    base64: string;
  } | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const eventSourceRef = useRef<EventSource | null>(null);

  const activeTheme = THEME_PRESETS[themeId] || THEME_PRESETS.liquid_glass;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 40 * 1024 * 1024) {
      setErrorText('File size must be below 40MB.');
      return;
    }

    let detectedType: 'image' | 'video' | 'audio' | null = null;
    const mime = file.type.toLowerCase();
    if (mime.startsWith('image/')) {
      detectedType = 'image';
    } else if (mime.startsWith('video/')) {
      detectedType = 'video';
    } else if (mime.startsWith('audio/') || mime.includes('music')) {
      detectedType = 'audio';
    }

    if (!detectedType) {
      setErrorText('Only Images, Videos, and Audio/Music formats are permitted.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const resultStr = reader.result as string;
      const base64Data = resultStr.split(',')[1];
      setSelectedFile({
        name: file.name,
        type: detectedType,
        base64: base64Data
      });
    };
    reader.onerror = () => {
      setErrorText('Decoding of local attachment failed.');
    };
    reader.readAsDataURL(file);
  };

  // Sync state settings to local storage
  useEffect(() => {
    localStorage.setItem('app_theme', themeId);
  }, [themeId]);

  useEffect(() => {
    localStorage.setItem('avatar_gradient', avatarGradient);
  }, [avatarGradient]);

  useEffect(() => {
    localStorage.setItem('bubble_theme', bubbleTheme);
  }, [bubbleTheme]);

  // Handle transient notifications clears
  useEffect(() => {
    if (errorText) {
      const t = setTimeout(() => setErrorText(null), 6000);
      return () => clearTimeout(t);
    }
  }, [errorText]);

  useEffect(() => {
    if (successText) {
      const t = setTimeout(() => setSuccessText(null), 5000);
      return () => clearTimeout(t);
    }
  }, [successText]);

  // Auth synchronization check
  useEffect(() => {
    if (token) {
      fetch('/api/users/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      .then(res => {
        if (!res.ok) {
          throw new Error('Verification failed');
        }
        return res.json();
      })
      .then(data => {
        setCurrentUser(data.user);
        localStorage.setItem('chat_user', JSON.stringify(data.user));
        
        // Sync custom theme features initialized from server
        if (data.user.customTheme) {
          setThemeId(data.user.customTheme);
        }
        if (data.user.avatarGradient) {
          setAvatarGradient(data.user.avatarGradient);
        }
        if (data.user.statusText) {
          setStatusTextInput(data.user.statusText);
        }
      })
      .catch(() => {
        handleLogout();
      });
    }
  }, [token]);

  // Live database updates
  useEffect(() => {
    if (token && currentUser) {
      fetchFriends();
    }
  }, [token, currentUser]);

  // Chat window automatic scroll locks
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, selectedFriend]);

  // Push updates SSE Connection
  useEffect(() => {
    if (token && currentUser) {
      setupRealTimeStream();
    } else {
      cleanupRealTimeStream();
    }
    return () => cleanupRealTimeStream();
  }, [token, currentUser, selectedFriend]);

  // Fetch message loop on conversation change
  useEffect(() => {
    if (token && selectedFriend) {
      fetchMessages(selectedFriend.id);
    } else {
      setMessages([]);
    }
  }, [selectedFriend, token]);

  const fetchFriends = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/friends/list', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setFriendsList(data);
      }
    } catch {
      console.error('Core routing error fetching friends list');
    }
  };

  const fetchMessages = async (friendId: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/chats/${friendId}/messages`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setMessages(data);
      }
    } catch {
      console.error('Core routing error fetching conversations list');
    }
  };

  const setupRealTimeStream = () => {
    cleanupRealTimeStream();

    const streamUrl = `/api/chats/stream?token=${encodeURIComponent(token || '')}`;
    const es = new EventSource(streamUrl);
    eventSourceRef.current = es;

    es.onopen = () => {
      setIsSseConnected(true);
    };

    es.onerror = () => {
      setIsSseConnected(false);
    };

    es.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);

        if (payload.connected) {
          setIsSseConnected(true);
          return;
        }

        if (payload.ping) {
          return;
        }

        // Live Chat Bubble Recv
        if (payload.type === 'message_incoming') {
          const msg = payload.message as Message;
          if (
            selectedFriend &&
            ((msg.senderId === selectedFriend.id && msg.receiverId === currentUser?.id) ||
             (msg.senderId === currentUser?.id && msg.receiverId === selectedFriend.id))
          ) {
            setMessages(prev => {
              if (prev.find(m => m.id === msg.id)) return prev;
              return [...prev, msg];
            });
          }
        }

        // Live Chat Message Deletion Recv
        if (payload.type === 'message_deleted') {
          setMessages(prev => prev.filter(m => m.id !== payload.messageId));
        }

        // New friend dynamic request arrived
        if (payload.type === 'friend_added') {
          fetchFriends();
          setSuccessText(`@${payload.friend.username} linked to your conversations!`);
        }

        // Live Friend Profile updates dynamic mapping
        if (payload.type === 'friend_updated') {
          const updated = payload.user;
          setFriendsList(prev => prev.map(f => {
            if (f.id === updated.id) {
              return {
                ...f,
                displayName: updated.displayName,
                statusText: updated.statusText,
                avatarGradient: updated.avatarGradient
              };
            }
            return f;
          }));

          // Active chat headers update instantly
          if (selectedFriend && selectedFriend.id === updated.id) {
            setSelectedFriend(prev => prev ? {
              ...prev,
              displayName: updated.displayName,
              statusText: updated.statusText,
              avatarGradient: updated.avatarGradient
            } : null);
          }
        }

      } catch (err) {
        console.error('Error executing message bundle:', err);
      }
    };
  };

  const cleanupRealTimeStream = () => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
      eventSourceRef.current = null;
    }
    setIsSseConnected(false);
  };

  // Profile Customization Push API
  const applyProfileCustomizations = async (customDisplayName: string, customStatus: string, selectedGrad: string, selTheme: string) => {
    if (!token) return;
    try {
      const res = await fetch('/api/users/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          displayName: customDisplayName,
          statusText: customStatus,
          avatarGradient: selectedGrad,
          customTheme: selTheme
        })
      });

      const data = await res.json();
      if (res.ok) {
        setCurrentUser(data.user);
        localStorage.setItem('chat_user', JSON.stringify(data.user));
        return true;
      } else {
        throw new Error(data.error);
      }
    } catch (err: any) {
      setErrorText(err.message || 'Customization application failed.');
      return false;
    }
  };

  // Authenticate user
  const handleAuth = async (e: FormEvent) => {
    e.preventDefault();
    if (!usernameInput || !passwordInput) {
      setErrorText('Please specify both valid username and password credentials.');
      return;
    }

    setIsLoading(true);
    setErrorText(null);

    const path = isRegister ? '/api/auth/register' : '/api/auth/login';
    const body = isRegister 
      ? { username: usernameInput, password: passwordInput, displayName: displayNameInput || usernameInput }
      : { username: usernameInput, password: passwordInput };

    try {
      const res = await fetch(path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Server rejected credentials.');
      }

      localStorage.setItem('chat_token', data.token);
      localStorage.setItem('chat_user', JSON.stringify(data.user));
      setToken(data.token);
      setCurrentUser(data.user);
      
      setSuccessText(isRegister ? 'Account established successfully! Hello!' : 'Access and secure workspace granted!');
      
      // Auto settings sync on register/login
      if (data.user.customTheme) setThemeId(data.user.customTheme);
      if (data.user.avatarGradient) setAvatarGradient(data.user.avatarGradient);
      if (data.user.statusText) setStatusTextInput(data.user.statusText);

      setUsernameInput('');
      setPasswordInput('');
      setDisplayNameInput('');
    } catch (err: any) {
      setErrorText(err.message || 'Verification failure.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    cleanupRealTimeStream();
    localStorage.removeItem('chat_token');
    localStorage.removeItem('chat_user');
    setToken(null);
    setCurrentUser(null);
    setSelectedFriend(null);
    setFriendsList([]);
    setMessages([]);
    setIsSettingsOpen(false);
    setSuccessText('Logged out safely. Goodbye!');
  };

  // Add friend
  const handleAddFriend = async (e: FormEvent) => {
    e.preventDefault();
    if (!friendUsernameInput.trim()) return;

    setErrorText(null);
    setSuccessText(null);

    try {
      const res = await fetch('/api/friends/add', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ username: friendUsernameInput })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Could not map user.');
      }

      setSuccessText(`Added @${data.friend.username} to your chat list!`);
      setFriendUsernameInput('');
      fetchFriends();
    } catch (err: any) {
      setErrorText(err.message || 'Operation failed.');
    }
  };

  // Message push supporting media attachments and optional description captions
  const handleSendMessage = async (e: FormEvent) => {
    e.preventDefault();
    if ((!messageText.trim() && !selectedFile) || !selectedFriend) return;

    let uploadedUrl = '';
    const fileToUpload = selectedFile;
    const captionText = messageText;

    // Fast-reset inputs on UI thread to give ultra fluid interface response
    setMessageText('');
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }

    try {
      setIsUploading(true);
      if (fileToUpload) {
        const uploadRes = await fetch('/api/uploads', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            filename: fileToUpload.name,
            fileType: fileToUpload.type,
            base64: fileToUpload.base64
          })
        });
        const uploadData = await uploadRes.json();
        if (!uploadRes.ok) {
          throw new Error(uploadData.error || 'Upload failed.');
        }
        uploadedUrl = uploadData.mediaUrl;
      }

      const res = await fetch(`/api/chats/${selectedFriend.id}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ 
          text: captionText,
          mediaType: fileToUpload?.type,
          mediaUrl: uploadedUrl || undefined
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Transmission failed.');
      }

      setMessages(prev => {
        if (prev.find(m => m.id === data.id)) return prev;
        return [...prev, data];
      });
    } catch (err: any) {
      setErrorText(err.message || 'Transmission failed.');
    } finally {
      setIsUploading(false);
    }
  };

  // Message delete API
  const handleDeleteMessage = async (messageId: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/chats/messages/${messageId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Deletion failed.');
      }
      setMessages(prev => prev.filter(m => m.id !== messageId));
      setSuccessText('Message has been permanently deleted.');
    } catch (err: any) {
      setErrorText(err.message || 'Failed to delete message.');
    }
  };

  const filteredFriends = friendsList.filter(f => {
    const rawFilter = friendsFilter.toLowerCase();
    return (
      f.username.toLowerCase().includes(rawFilter) ||
      f.displayName.toLowerCase().includes(rawFilter)
    );
  });

  return (
    <div className={`absolute inset-0 ${activeTheme.bgClass} text-slate-100 flex flex-col font-sans overflow-hidden antialiased select-none transition-colors duration-1000`}>
      
      {/* Dynamic Swirling Liquified Background Blobs - ONLY for glass themes */}
      {activeTheme.glassMorphism && (
        <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
          <motion.div 
            initial={{ x: '10%', y: '10%', scale: 1 }}
            animate={{ 
              x: ['10%', '65%', '35%', '10%'],
              y: ['10%', '35%', '70%', '10%'],
              scale: [1, 1.2, 0.9, 1]
            }}
            transition={{ duration: 24, repeat: Infinity, ease: "linear" }}
            className="absolute w-[450px] h-[450px] rounded-full bg-gradient-to-tr from-cyan-400/25 via-teal-500/15 to-transparent blur-[90px]"
          />
          <motion.div 
            initial={{ x: '80%', y: '80%', scale: 1.1 }}
            animate={{ 
              x: ['80%', '25%', '55%', '80%'],
              y: ['80%', '65%', '15%', '80%'],
              scale: [1.1, 0.8, 1.2, 1.1]
            }}
            transition={{ duration: 28, repeat: Infinity, ease: "linear" }}
            className="absolute w-[500px] h-[500px] rounded-full bg-gradient-to-tr from-fuchsia-500/20 via-pink-500/10 to-transparent blur-[110px]"
          />
          <motion.div 
            initial={{ x: '45%', y: '15%', scale: 0.9 }}
            animate={{ 
              x: ['45%', '75%', '15%', '45%'],
              y: ['15%', '85%', '45%', '15%'],
              scale: [0.9, 1.1, 0.8, 0.9]
            }}
            transition={{ duration: 19, repeat: Infinity, ease: "linear" }}
            className="absolute w-[380px] h-[380px] rounded-full bg-gradient-to-tr from-sky-400/20 via-indigo-500/20 to-transparent blur-[80px]"
          />
        </div>
      )}

      {/* Persistent Notification Badge Container */}
      <div className="fixed top-4 right-4 z-50 flex flex-col gap-2.5 max-w-sm pointer-events-none">
        <AnimatePresence>
          {errorText && (
            <motion.div
              initial={{ opacity: 0, y: -25, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-red-950/95 border border-red-500/30 text-red-100 px-4 py-3.5 rounded-2xl shadow-2xl backdrop-blur-xl flex items-start gap-2.5 pointer-events-auto"
            >
              <AlertCircle size={18} className="shrink-0 mt-0.5 text-red-400" />
              <div className="text-xs font-semibold leading-relaxed">{errorText}</div>
            </motion.div>
          )}

          {successText && (
            <motion.div
              initial={{ opacity: 0, y: -25, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-teal-950/95 border border-teal-500/30 text-teal-100 px-4 py-3.5 rounded-2xl shadow-2xl backdrop-blur-xl flex items-start gap-2.5 pointer-events-auto"
            >
              <CheckCircle2 size={18} className="shrink-0 mt-0.5 text-teal-400" />
              <div className="text-xs font-semibold leading-relaxed">{successText}</div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* MAIN CONTAINER */}
      <div className="flex-1 w-full flex items-center justify-center p-0 md:p-4 z-10 overflow-hidden relative">
        <div className="w-full h-full max-w-7xl flex flex-col rounded-none md:rounded-[28px] overflow-hidden relative">
          
          {!currentUser ? (
            // --- AUTHENTICATION INTERFACE (Single View Card) ---
            <div className="flex-1 flex flex-col items-center justify-center p-6 relative overflow-y-auto">
              <motion.div 
                initial={{ opacity: 0, scale: 0.93, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ type: 'spring', damping: 25, stiffness: 150 }}
                className={`w-full max-w-md ${activeTheme.panelClass} p-8 border relative overflow-hidden`}
              >
                {/* Refractive flare highlights */}
                {activeTheme.glassMorphism && (
                  <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-white/40 to-transparent" />
                )}

                {/* App Brand Header */}
                <div className="flex flex-col items-center text-center mb-6">
                  <motion.div 
                    whileHover={{ scale: 1.05, rotate: 5 }}
                    whileTap={{ scale: 0.95 }}
                    className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-teal-400 to-sky-500 flex items-center justify-center shadow-lg mb-4 ring-4 ring-white/10"
                  >
                    <MessageSquare className="text-slate-950" size={32} />
                  </motion.div>
                  <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
                    <span>Tahoe Glass Chat</span>
                    <Sparkles size={16} className="text-teal-400 animate-pulse" />
                  </h1>
                  <p className="text-xs text-slate-400 mt-1.5 leading-normal max-w-xs">
                    No email or phone required. Instantly deploy your usernames and password to register/login.
                  </p>
                </div>

                {/* Tabs */}
                <div className="grid grid-cols-2 p-1 bg-slate-950/70 border border-white/5 rounded-2xl mb-6">
                  <button
                    type="button"
                    onClick={() => {
                      setIsRegister(false);
                      setErrorText(null);
                    }}
                    className={`py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                      !isRegister 
                        ? 'bg-white/10 text-white shadow-soft font-bold' 
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Sign In
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsRegister(true);
                      setErrorText(null);
                    }}
                    className={`py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                      isRegister 
                        ? 'bg-white/10 text-white shadow-soft font-bold' 
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Create Account
                  </button>
                </div>

                {/* Credentials submission form */}
                <form onSubmit={handleAuth} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 pl-1">
                      Username Identity
                    </label>
                    <div className="relative">
                      <span className="absolute left-3.5 top-2.5 text-slate-500 text-sm font-semibold">@</span>
                      <input
                        type="text"
                        required
                        value={usernameInput}
                        onChange={(e) => setUsernameInput(e.target.value.replace(/[^a-zA-Z0-9_]/g, ''))}
                        placeholder="tahoe_pilot"
                        className="w-full pl-8 pr-4 py-2 bg-slate-950/90 border border-white/10 rounded-xl text-slate-100 placeholder-slate-600 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/50 transition-all duration-200"
                      />
                    </div>
                  </div>

                  {isRegister && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      transition={{ duration: 0.25 }}
                      className="space-y-1.5"
                    >
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-1">
                        Friendly Display Name
                      </label>
                      <input
                        type="text"
                        value={displayNameInput}
                        onChange={(e) => setDisplayNameInput(e.target.value)}
                        placeholder="Captain Tahoe"
                        className="w-full px-3.5 py-2 bg-slate-950/90 border border-white/10 rounded-xl text-slate-100 placeholder-slate-600 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/50 transition-all duration-200"
                      />
                    </motion.div>
                  )}

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 pl-1">
                      Safe Keys / Password
                    </label>
                    <div className="relative">
                      <input
                        type="password"
                        required
                        value={passwordInput}
                        onChange={(e) => setPasswordInput(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-3.5 pr-10 py-2 bg-slate-950/90 border border-white/10 rounded-xl text-slate-100 placeholder-slate-600 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/50 transition-all "
                      />
                      <span className="absolute right-3.5 top-2.5 text-slate-600">
                        <Lock size={16} />
                      </span>
                    </div>
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 bg-gradient-to-r from-teal-400 to-sky-400 text-slate-950 font-bold rounded-xl text-xs uppercase tracking-wider transition-all focus:outline-none focus:ring-2 focus:ring-teal-400/50 active:scale-98 relative flex items-center justify-center gap-2 cursor-pointer shadow-xl shadow-teal-500/20"
                  >
                    {isLoading ? (
                      <Loader2 className="animate-spin text-slate-950" size={16} />
                    ) : (
                      <span className="flex items-center gap-1.5">
                        {isRegister ? 'Complete Registration' : 'Secure Entry'} <Sparkles size={13} />
                      </span>
                    )}
                  </motion.button>
                </form>

                <div className="mt-6 pt-5 border-t border-white/5 text-center">
                  <span className="text-[10px] text-slate-500 font-medium">
                    Credentials remain encrypted within safe local storage networks.
                  </span>
                </div>
              </motion.div>
            </div>
          ) : (
            
            // --- FULL DUAL PANE ENVIRONMENT (Dashboard Layout) ---
            <div className={`flex-1 flex flex-col md:flex-row h-full overflow-hidden select-text relative border ${activeTheme.borderClass} ${activeTheme.panelClass}`}>
              
              {/* --- SIDEBAR PANEL (Friends & Connection status) --- */}
              <div className={`w-full md:w-80 lg:w-96 border-r ${activeTheme.borderClass} bg-slate-950/40 backdrop-blur-md flex flex-col ${selectedFriend ? 'hidden md:flex' : 'flex'}`}>
                
                {/* Profile Header */}
                <div className="p-4 border-b border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-3 min-w-0">
                    <motion.div 
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => setIsSettingsOpen(true)}
                      className="cursor-pointer"
                    >
                      <UserAvatar 
                        gradientId={currentUser.avatarGradient} 
                        displayName={currentUser.displayName} 
                        size="md" 
                      />
                    </motion.div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="text-xs font-bold text-white truncate max-w-[120px] lg:max-w-[150px]">
                          {currentUser.displayName}
                        </span>
                        <Sparkles size={11} className="text-teal-400 shrink-0" />
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono truncate max-w-[130px]">
                        @{currentUser.username}
                      </div>
                      {currentUser.statusText && (
                        <div className="text-[10px] text-teal-300 font-medium truncate max-w-[130px] italic">
                          "{currentUser.statusText}"
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions (Settings Gear & Logout) */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => setIsSettingsOpen(true)}
                      title="Custom Appearance & Settings"
                      className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 active:bg-white/15 text-slate-300 border border-white/10 flex items-center justify-center transition"
                    >
                      <Palette size={14} className="text-teal-400 animate-spin-slow" />
                    </motion.button>

                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={handleLogout}
                      title="Sign Out"
                      className="w-8 h-8 rounded-xl bg-red-950/40 hover:bg-red-900/30 text-red-400 border border-red-500/20 flex items-center justify-center transition"
                    >
                      <LogOut size={14} />
                    </motion.button>
                  </div>
                </div>

                {/* Connection Health status */}
                <div className="px-4 py-2 bg-white/5 border-b border-white/5 flex items-center justify-between text-[10px]">
                  <span className="text-slate-400 font-medium font-mono">SSE Network Hub</span>
                  <div className="flex items-center gap-1.5">
                    <span className={`w-1.5 h-1.5 rounded-full ${isSseConnected ? 'bg-emerald-400' : 'bg-amber-400 animate-ping'}`} />
                    <span className={isSseConnected ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                      {isSseConnected ? 'Active' : 'Connecting...'}
                    </span>
                  </div>
                </div>

                {/* Friend Addition input */}
                <div className="p-4 bg-white/5 border-b border-white/5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 pl-0.5">
                    Identify Friend Link
                  </label>
                  <form onSubmit={handleAddFriend} className="flex gap-2">
                    <div className="relative flex-1">
                      <span className="absolute left-3 top-2 text-xs text-indigo-300 font-bold font-mono">@</span>
                      <input
                        type="text"
                        value={friendUsernameInput}
                        onChange={(e) => setFriendUsernameInput(e.target.value.replace(/[^a-zA-Z0-9_]/g, ''))}
                        placeholder="pilot_username"
                        className="w-full pl-6 pr-3 py-1.5 bg-slate-950/80 border border-white/5 rounded-lg text-slate-100 placeholder-slate-600 text-xs focus:outline-none focus:ring-1 focus:ring-teal-400 transition"
                      />
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      type="submit"
                      disabled={!friendUsernameInput.trim()}
                      className="px-3 bg-teal-400 text-slate-950 font-bold rounded-lg text-xs hover:bg-teal-300 transition shrink-0 disabled:opacity-40"
                    >
                      <UserPlus size={14} />
                    </motion.button>
                  </form>
                </div>

                {/* Filters */}
                <div className="px-4 py-2 border-b border-white/5 flex items-center bg-slate-950/20">
                  <div className="relative w-full">
                    <Search className="absolute left-3 top-2.5 text-slate-500" size={13} />
                    <input
                      type="text"
                      placeholder="Filter friends list..."
                      value={friendsFilter}
                      onChange={(e) => setFriendsFilter(e.target.value)}
                      className="w-full pl-8 pr-3 py-2 bg-transparent text-xs text-slate-300 placeholder-slate-600 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Friends List Scroll Frame */}
                <div className="flex-1 overflow-y-auto custom-scrollbar">
                  <div className="px-4 py-2 bg-white/5 text-[9px] font-bold text-slate-400 uppercase tracking-widest flex justify-between items-center">
                    <span>Direct Messengers ({filteredFriends.length})</span>
                    <Users size={11} className="text-slate-500" />
                  </div>

                  {filteredFriends.length === 0 ? (
                    <div className="px-5 py-10 text-center">
                      <Compass className="mx-auto text-slate-700 mb-3 animate-spin-slow" size={28} />
                      <div className="text-xs text-slate-400 font-semibold mb-1">No channels opened</div>
                      <p className="text-[10px] text-slate-500 leading-relaxed max-w-[200px] mx-auto">
                        Type in a friend’s exact username identity in the link section above to establish real-time links.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-0.5 p-2">
                      {filteredFriends.map((friend) => {
                        const isSelected = selectedFriend?.id === friend.id;
                        return (
                          <motion.button
                            key={friend.id}
                            type="button"
                            onClick={() => setSelectedFriend(friend)}
                            className={`w-full p-2.5 rounded-2xl cursor-pointer flex items-center justify-between text-left transition-all relative overflow-hidden ${
                              isSelected 
                                ? 'bg-white/10 text-white border-l-4 border-l-teal-400 pl-3 shadow-lg' 
                                : 'hover:bg-white/5 text-slate-300 hover:text-white'
                            }`}
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <UserAvatar 
                                gradientId={friend.avatarGradient} 
                                displayName={friend.displayName} 
                                isOnline={friend.isOnline} 
                                size="sm" 
                              />
                              
                              <div className="min-w-0">
                                <div className="text-xs font-bold truncate leading-tight">
                                  {friend.displayName}
                                </div>
                                <div className="text-[9px] text-slate-500 font-mono truncate leading-normal">
                                  @{friend.username}
                                </div>
                                {friend.statusText && (
                                  <div className="text-[10px] text-teal-400/80 truncate italic">
                                    {friend.statusText}
                                  </div>
                                )}
                              </div>
                            </div>

                            {friend.isOnline && (
                              <span className="text-[8px] text-emerald-400 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded-md uppercase tracking-tight">
                                Live
                              </span>
                            )}
                          </motion.button>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              {/* --- CHAT DIALOGUE WORKSPACE PANEL --- */}
              <div className={`flex-1 flex flex-col bg-slate-950/20 backdrop-blur-lg ${!selectedFriend ? 'hidden md:flex' : 'flex'}`}>
                <AnimatePresence mode="wait">
                  {selectedFriend ? (
                    
                    // Selected Conversation Dialogue View
                    <motion.div 
                      key={selectedFriend.id}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.15 }}
                      className="flex-1 flex flex-col overflow-hidden relative"
                    >
                      {/* Active header bar */}
                      <div className="px-4 py-3 bg-slate-950/45 border-b border-white/5 flex items-center justify-between">
                        <div className="flex items-center gap-3 min-w-0">
                          {/* mobile collapse helper */}
                          <motion.button
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            type="button"
                            onClick={() => setSelectedFriend(null)}
                            className="md:hidden w-8 h-8 rounded-xl bg-white/5 flex items-center justify-center text-slate-400 mr-1"
                          >
                            <ArrowLeft size={16} />
                          </motion.button>

                          <UserAvatar 
                            gradientId={selectedFriend.avatarGradient} 
                            displayName={selectedFriend.displayName} 
                            isOnline={selectedFriend.isOnline} 
                            size="md" 
                          />

                          <div className="min-w-0">
                            <div className="text-xs font-bold text-white truncate break-words">
                              {selectedFriend.displayName}
                            </div>
                            <div className="text-[9px] text-slate-400 font-mono flex items-center gap-1.5">
                              <span>@{selectedFriend.username}</span>
                              <span className="text-slate-500">•</span>
                              {selectedFriend.isOnline ? (
                                <span className="text-emerald-400 flex items-center gap-1 font-semibold animate-pulse">
                                  Online
                                </span>
                              ) : (
                                <span className="text-slate-500">Offline</span>
                              )}
                            </div>
                          </div>
                        </div>

                        {selectedFriend.statusText && (
                          <div className="hidden lg:block text-[10px] text-right text-teal-300 font-medium italic truncate max-w-xs pr-4">
                            "{selectedFriend.statusText}"
                          </div>
                        )}
                      </div>

                      {/* Messaging history window */}
                      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4 custom-scrollbar bg-slate-950/15">
                        
                        {/* Conversation start banner */}
                        <div className="py-6 flex flex-col items-center text-center">
                          <motion.div 
                            animate={{ scale: [1, 1.05, 1] }} 
                            transition={{ duration: 3, repeat: Infinity }}
                            className="w-10 h-10 rounded-full bg-slate-950/80 border border-white/15 flex items-center justify-center text-teal-400 mb-2.5"
                          >
                            <Lock size={15} />
                          </motion.div>
                          <div className="text-[10px] font-bold text-slate-400 tracking-wider uppercase mb-1">
                            Secured Direct Link
                          </div>
                          <p className="text-[9px] text-slate-500 max-w-xs leading-normal">
                            All transmissions are routed immediately as Server Sent Events. Communication starts here with @{selectedFriend.username}.
                          </p>
                        </div>

                        {/* Dialogue bubble loops */}
                        {messages.length === 0 ? (
                          <div className="py-14 text-center text-xs text-slate-500 italic font-medium">
                            No packet messages exchanged yet. Send a greetings text below!
                          </div>
                        ) : (
                          <div className="space-y-4">
                            {messages.map((message) => {
                              const isMe = message.senderId === currentUser.id;
                              const bubbleStyle = BUBBLE_GRADIENTS[bubbleTheme] || BUBBLE_GRADIENTS.tahoe_teal;
                              const formattedTime = new Date(message.timestamp).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit'
                              });

                              return (
                                <motion.div 
                                  initial={{ opacity: 0, y: 10, scale: 0.96 }}
                                  animate={{ opacity: 1, y: 0, scale: 1 }}
                                  transition={{ type: 'spring', damping: 18, stiffness: 200 }}
                                  key={message.id} 
                                  className={`flex ${isMe ? 'justify-end' : 'justify-start'} mb-1`}
                                >
                                  <div className={`flex items-center gap-2 group max-w-[85%] md:max-w-[75%] ${isMe ? 'flex-row-reverse' : 'flex-row'}`}>
                                    {/* Bubble Core container */}
                                    <div className={`rounded-2xl px-4 py-2.5 shadow-md flex flex-col transition-all duration-300 ${
                                      isMe 
                                        ? `${bubbleStyle.meClasses} rounded-tr-none` 
                                        : `${bubbleStyle.friendClasses} rounded-tl-none`
                                    }`}>
                                      {/* Attached Media Asset */}
                                      {message.mediaUrl && (
                                        <div className="mb-2 max-w-full">
                                          {message.mediaType === 'image' && (
                                            <div className="relative rounded-xl overflow-hidden border border-white/10 shadow-lg bg-black/15">
                                              <img 
                                                src={message.mediaUrl} 
                                                alt="media asset" 
                                                referrerPolicy="no-referrer"
                                                className="max-h-72 w-auto max-w-full object-cover rounded-xl"
                                              />
                                            </div>
                                          )}
                                          {message.mediaType === 'video' && (
                                            <div className="relative rounded-xl overflow-hidden border border-white/10 shadow-lg bg-black/40">
                                              <video 
                                                src={message.mediaUrl} 
                                                controls 
                                                className="max-h-72 w-full object-contain rounded-xl"
                                              />
                                            </div>
                                          )}
                                          {message.mediaType === 'audio' && (
                                            <div className="p-2.5 rounded-xl border border-white/10 bg-slate-950/60 flex flex-col gap-1.5 w-60">
                                              <div className="flex items-center gap-2 text-[10px] text-teal-400 font-mono">
                                                <MusicIcon size={12} className="animate-pulse text-teal-400" />
                                                <span className="truncate font-semibold">Audio Track</span>
                                              </div>
                                              <audio 
                                                src={message.mediaUrl} 
                                                controls 
                                                className="w-full h-8 accent-teal-400 select-none"
                                              />
                                            </div>
                                          )}
                                        </div>
                                      )}

                                      {/* Text Caption */}
                                      {message.text && (
                                        <p className="text-xs break-words leading-relaxed whitespace-pre-wrap select-text">
                                          {message.text}
                                        </p>
                                      )}

                                      {/* Timestamp info */}
                                      <span className={`text-[8px] mt-1.5 font-mono select-none ${
                                        isMe ? 'opacity-85 self-end text-[10px]' : 'self-end text-slate-550'
                                      }`}>
                                        {formattedTime}
                                      </span>
                                    </div>

                                    {/* Hover Action delete overlay */}
                                    {isMe && (
                                      <motion.button
                                        whileHover={{ scale: 1.12 }}
                                        whileTap={{ scale: 0.9 }}
                                        onClick={() => handleDeleteMessage(message.id)}
                                        title="Delete Message"
                                        className="opacity-0 group-hover:opacity-100 p-2 rounded-xl bg-red-950/70 hover:bg-red-900/80 text-red-400 border border-red-500/15 flex items-center justify-center transition-all duration-200 cursor-pointer text-xs shrink-0"
                                      >
                                        <Trash2 size={13} />
                                      </motion.button>
                                    )}
                                  </div>
                                </motion.div>
                              );
                            })}
                            <div ref={messagesEndRef} />
                          </div>
                        )}
                      </div>

                      {/* Text Input Footer bar */}
                      <div className="p-4 bg-slate-950/60 border-t border-white/5">
                        {/* Attachment Preview Panel */}
                        <AnimatePresence>
                          {selectedFile && (
                            <motion.div
                              initial={{ opacity: 0, y: 15, scale: 0.95 }}
                              animate={{ opacity: 1, y: 0, scale: 1 }}
                              exit={{ opacity: 0, y: 10, scale: 0.95 }}
                              className="p-3 bg-slate-900 border border-white/10 rounded-2xl mb-3 flex items-center justify-between relative shadow-2xl backdrop-blur-md"
                            >
                              <div className="flex items-center gap-3 min-w-0">
                                {selectedFile.type === 'image' && (
                                  <div className="w-12 h-12 rounded-lg overflow-hidden border border-white/15 bg-slate-950 shrink-0 relative flex items-center justify-center">
                                    <img 
                                      src={`data:image;base64,${selectedFile.base64}`} 
                                      alt="preview" 
                                      className="w-full h-full object-cover" 
                                      referrerPolicy="no-referrer"
                                    />
                                    <ImageIcon size={14} className="absolute bottom-1 right-1 text-teal-400 bg-slate-950/80 p-0.5 rounded" />
                                  </div>
                                )}
                                {selectedFile.type === 'video' && (
                                  <div className="w-12 h-12 rounded-lg bg-teal-950/65 border border-teal-500/20 flex items-center justify-center shrink-0 relative">
                                    <VideoIcon size={18} className="text-teal-400" />
                                    <span className="absolute bottom-1 right-1 text-[8px] bg-slate-950/80 p-0.5 rounded font-mono font-bold text-teal-400">VID</span>
                                  </div>
                                )}
                                {selectedFile.type === 'audio' && (
                                  <div className="w-12 h-12 rounded-lg bg-indigo-950/65 border border-indigo-500/20 flex items-center justify-center shrink-0 relative">
                                    <MusicIcon size={18} className="text-indigo-400 animate-pulse" />
                                    <span className="absolute bottom-1 right-1 text-[8px] bg-slate-950/80 p-0.5 rounded font-mono font-bold text-indigo-400">AUD</span>
                                  </div>
                                )}

                                <div className="min-w-0">
                                  <div className="text-xs font-bold text-white truncate max-w-[200px] sm:max-w-[300px]">
                                    {selectedFile.name}
                                  </div>
                                  <div className="text-[9px] text-slate-400 font-mono capitalize">
                                    Ready to upload and broadcast ({selectedFile.type})
                                  </div>
                                </div>
                              </div>

                              <motion.button
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                                type="button"
                                onClick={() => {
                                  setSelectedFile(null);
                                  if (fileInputRef.current) fileInputRef.current.value = '';
                                }}
                                className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/15 text-slate-400 flex items-center justify-center transition cursor-pointer"
                              >
                                <X size={14} />
                              </motion.button>
                            </motion.div>
                          )}
                        </AnimatePresence>

                        <form onSubmit={handleSendMessage} className="flex gap-2 items-center">
                          {/* Hidden File input */}
                          <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleFileChange}
                            accept="image/*,video/*,audio/*"
                            className="hidden"
                          />

                          {/* Attachment Trigger */}
                          <motion.button
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            type="button"
                            disabled={isUploading}
                            onClick={() => fileInputRef.current?.click()}
                            className="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-slate-300 transition shrink-0 disabled:opacity-40 cursor-pointer"
                            title="Attach Image, Video or Music Track"
                          >
                            <Paperclip size={16} />
                          </motion.button>

                          <input
                            type="text"
                            value={messageText}
                            onChange={(e) => setMessageText(e.target.value)}
                            disabled={isUploading}
                            placeholder={
                              isUploading 
                                ? "Uploading attachment files..." 
                                : selectedFile 
                                  ? "Add caption description layout (Optional)..." 
                                  : `Type private text message to @${selectedFriend.username}...`
                            }
                            className="flex-1 px-4 py-2.5 bg-slate-950 border border-white/10 rounded-xl text-slate-100 placeholder-slate-500 text-xs focus:outline-none focus:ring-1 focus:ring-teal-400 focus:border-teal-400 transition-all font-sans disabled:opacity-50"
                          />

                          <motion.button
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            type="submit"
                            disabled={(!messageText.trim() && !selectedFile) || isUploading}
                            className="w-10 h-10 rounded-xl bg-teal-400 text-slate-950 flex items-center justify-center font-bold hover:bg-teal-300 transition shadow-lg disabled:opacity-40 shrink-0 cursor-pointer"
                          >
                            {isUploading ? (
                              <Loader2 size={15} className="animate-spin text-slate-950" />
                            ) : (
                              <Send size={15} className="ml-0.5 text-slate-950" />
                            )}
                          </motion.button>
                        </form>
                      </div>

                    </motion.div>
                  ) : (
                    
                    // Standby Display Panel when no channel is focus-locked
                    <div className="flex-1 flex flex-col items-center justify-center p-8 text-center relative">
                      <motion.div 
                        animate={{ 
                          y: [0, -10, 0],
                        }}
                        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                        className="w-16 h-16 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-center text-teal-400 mb-5 shadow-2xl backdrop-blur-md"
                      >
                        <MessageSquarePlus size={28} />
                      </motion.div>
                      <h3 className="text-md font-bold text-white mb-2 tracking-tight">Direct Live Messaging Desk</h3>
                      <p className="text-xs text-slate-400 max-w-sm leading-relaxed mb-6">
                        No middle servers or records. Open any conversation bubble to securely stream messaging packets over SSE pipelines.
                      </p>
                      
                      {/* Dashboard status diagnostics */}
                      {friendsList.length > 0 && (
                        <div className="flex items-center gap-6 py-2 px-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur">
                          <div className="text-center">
                            <div className="text-xs font-extrabold text-white">{friendsList.length}</div>
                            <div className="text-[8px] text-slate-400 uppercase tracking-widest font-semibold">Active links</div>
                          </div>
                          <div className="w-px h-6 bg-white/10" />
                          <div className="text-center">
                            <div className="text-xs font-extrabold text-emerald-400">
                              {friendsList.filter(f => f.isOnline).length}
                            </div>
                            <div className="text-[8px] text-slate-400 uppercase tracking-widest font-semibold">Live Online</div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </AnimatePresence>
              </div>

              {/* --- SETTINGS & APPEARANCE DRAWER DIALOGUE --- */}
              <AnimatePresence>
                {isSettingsOpen && (
                  <div className="absolute inset-0 z-40 bg-slate-950/80 backdrop-blur-md flex justify-end">
                    
                    {/* Shadow dismissal zone */}
                    <div className="flex-1" onClick={() => setIsSettingsOpen(false)} />

                    {/* Settings main drawer */}
                    <motion.div
                      initial={{ x: '100%' }}
                      animate={{ x: 0 }}
                      exit={{ x: '100%' }}
                      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                      className="w-full max-w-md bg-slate-900 border-l border-white/10 h-full flex flex-col shadow-2xl relative"
                    >
                      {/* Drawer Head */}
                      <div className="p-4 border-b border-white/5 flex items-center justify-between bg-slate-950/30">
                        <div className="flex items-center gap-2">
                          <Palette size={18} className="text-teal-400" />
                          <h2 className="text-sm font-extrabold text-white">Appearance & Settings</h2>
                        </div>
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={() => setIsSettingsOpen(false)}
                          className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/15 text-slate-400 flex items-center justify-center transition"
                        >
                          <X size={14} />
                        </motion.button>
                      </div>

                      {/* Scrollable list of controls */}
                      <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar">
                        
                        {/* 1. App Theme Presets */}
                        <div className="space-y-3">
                          <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-0.5">
                            App Theme Theme
                          </label>
                          <div className="space-y-2">
                            {Object.values(THEME_PRESETS).map((t) => {
                              const isSel = themeId === t.id;
                              return (
                                <button
                                  key={t.id}
                                  onClick={() => setThemeId(t.id)}
                                  className={`w-full p-3 rounded-xl border text-left transition relative flex items-center justify-between ${
                                    isSel 
                                      ? 'bg-slate-950 border-teal-400 text-white shadow-md' 
                                      : 'bg-slate-950/40 border-white/5 text-slate-300 hover:bg-slate-950/80 hover:border-white/10'
                                  }`}
                                >
                                  <div>
                                    <div className="text-xs font-bold">{t.name}</div>
                                    <div className="text-[9px] text-slate-500 mt-0.5 font-medium pr-4">
                                      {t.description}
                                    </div>
                                  </div>
                                  {isSel && (
                                    <span className="w-5 h-5 rounded-full bg-teal-400 flex items-center justify-center shrink-0">
                                      <Check className="text-slate-950" size={12} />
                                    </span>
                                  )}
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        {/* 2. User Appearance Customizer */}
                        <div className="space-y-4 pt-4 border-t border-white/5">
                          <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-0.5">
                            User Profile Identity
                          </label>

                          {/* Instant live interactive preview */}
                          <div className="p-4 rounded-2xl bg-slate-950/60 border border-white/5 flex items-center gap-4">
                            <UserAvatar 
                              gradientId={avatarGradient} 
                              displayName={displayNameInput || currentUser.displayName} 
                              size="lg" 
                            />
                            <div className="min-w-0">
                              <div className="text-xs font-extrabold text-white truncate">
                                {displayNameInput || currentUser.displayName}
                              </div>
                              <div className="text-[10px] text-slate-400 font-mono">
                                @{currentUser.username}
                              </div>
                              <div className="text-[9px] text-teal-400 italic truncate mt-0.5">
                                "{statusTextInput || 'No status established'}"
                              </div>
                            </div>
                          </div>

                          {/* Display Name adjustment */}
                          <div className="space-y-1.5">
                            <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-0.5">
                              Custom Display Name
                            </span>
                            <div className="relative">
                              <input
                                type="text"
                                value={displayNameInput}
                                onChange={(e) => setDisplayNameInput(e.target.value)}
                                placeholder={currentUser.displayName}
                                className="w-full px-3.5 py-1.5 bg-slate-950 border border-white/10 rounded-xl text-slate-200 placeholder-slate-700 text-xs focus:ring-1 focus:ring-teal-400 focus:outline-none"
                              />
                              <span className="absolute right-3.5 top-2.5 text-slate-600">
                                <Edit2 size={13} />
                              </span>
                            </div>
                          </div>

                          {/* Custom Status message dynamic */}
                          <div className="space-y-1.5">
                            <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-0.5">
                              Status message
                            </span>
                            <input
                              type="text"
                              value={statusTextInput}
                              onChange={(e) => setStatusTextInput(e.target.value)}
                              placeholder="Available / Idle / Coding macOS..."
                              className="w-full px-3.5 py-1.5 bg-slate-950 border border-white/10 rounded-xl text-slate-200 placeholder-slate-600 text-xs focus:ring-1 focus:ring-teal-400 focus:outline-none"
                            />
                          </div>

                          {/* Avatar Gradient Choice slider */}
                          <div className="space-y-2">
                            <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-0.5">
                              Avatar Shield Paint
                            </span>
                            <div className="grid grid-cols-2 gap-2">
                              {Object.entries(AVATAR_GRADIENTS).map(([id, item]) => {
                                const isSel = avatarGradient === id;
                                return (
                                  <button
                                    key={id}
                                    onClick={() => setAvatarGradient(id)}
                                    className={`p-2 rounded-xl text-left border flex items-center gap-2 transition ${
                                      isSel 
                                        ? 'bg-slate-950 border-teal-400 text-white' 
                                        : 'bg-slate-950/20 border-white/5 text-slate-400 hover:bg-slate-950/40'
                                    }`}
                                  >
                                    <span className={`w-5 h-5 rounded-md ${item.classes}`} />
                                    <span className="text-[10px] font-bold truncate">{item.name}</span>
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>

                        {/* 3. Chat bubble presets */}
                        <div className="space-y-3 pt-4 border-t border-white/5">
                          <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-0.5">
                            My Chat Bubble Style
                          </label>
                          <div className="space-y-2">
                            {Object.entries(BUBBLE_GRADIENTS).map(([id, item]) => {
                              const isSel = bubbleTheme === id;
                              return (
                                <button
                                  key={id}
                                  onClick={() => setBubbleTheme(id)}
                                  className={`w-full p-2.5 rounded-xl border flex items-center justify-between text-left transition ${
                                    isSel 
                                      ? 'bg-slate-950 border-teal-400' 
                                      : 'bg-slate-950/30 border-white/5'
                                  }`}
                                >
                                  <div className="min-w-0">
                                    <div className="text-[11px] font-bold text-white">{item.name}</div>
                                    <div className="flex gap-1.5 mt-1">
                                      <span className={`px-2 py-0.5 text-[9px] rounded-md ${item.meClasses}`}>Me</span>
                                      <span className={`px-2 py-0.5 text-[9px] rounded-md ${item.friendClasses}`}>Friend</span>
                                    </div>
                                  </div>
                                  {isSel && (
                                    <span className="w-5.5 h-5.5 rounded-full bg-teal-400 flex items-center justify-center shrink-0">
                                      <Check className="text-slate-950" size={11} />
                                    </span>
                                  )}
                                </button>
                              );
                            })}
                          </div>
                        </div>

                      </div>

                      {/* Actions Footer */}
                      <div className="p-4 border-t border-white/10 bg-slate-950/80 flex gap-2">
                        <button
                          type="button"
                          onClick={() => setIsSettingsOpen(false)}
                          className="flex-1 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl text-xs hover:bg-slate-700 transition"
                        >
                          Discard
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            const finalDisplayName = displayNameInput.trim() || currentUser.displayName;
                            const success = await applyProfileCustomizations(finalDisplayName, statusTextInput, avatarGradient, themeId);
                            if (success) {
                              setSuccessText('Profile personalization has been successfully stored!');
                              setIsSettingsOpen(false);
                              fetchFriends(); // update local state lists
                            }
                          }}
                          className="flex-1 py-2 bg-gradient-to-r from-teal-400 to-sky-400 text-slate-950 font-bold rounded-xl text-xs hover:from-teal-300 hover:to-sky-300 shadow-lg"
                        >
                          Save Changes
                        </button>
                      </div>

                    </motion.div>
                  </div>
                )}
              </AnimatePresence>

            </div>
          )}

        </div>
      </div>

    </div>
  );
}
